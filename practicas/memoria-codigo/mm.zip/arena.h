// arena.h: asignador de memoria de tipo pila (último en entrar, primero en salir)
#ifndef ARENA_H
#define ARENA_H

#include <stddef.h>

// Reserva n bytes de la pila. Devuelve NULL si no hay espacio.
void *arena_alloc(size_t n);

// Libera p y TODO lo que se reservó después de p.
void arena_free(void *p);

// Cantidad de bytes actualmente en uso (útil para depurar).
size_t arena_used(void);

#endif
