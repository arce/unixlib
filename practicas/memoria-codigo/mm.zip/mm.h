// mm.h: asignador de memoria con lista libre (interfaz pública)
#ifndef MM_H
#define MM_H

#include <stddef.h>

typedef enum {
  MM_FIRST_FIT, // primer ajuste: el primer bloque libre que sirva
  MM_BEST_FIT   // mejor ajuste: el bloque libre más pequeño que sirva
} mm_strategy_t;

void *mm_malloc(size_t n);         // reserva n bytes (NULL si falla)
void mm_free(void *ptr);           // libera un bloque obtenido con mm_malloc
void mm_set_strategy(mm_strategy_t s);

// Depuración y pruebas
void mm_dump(void);                // imprime el mapa de la memoria
size_t mm_free_blocks(void);       // cantidad de bloques en la lista libre
size_t mm_free_bytes(void);        // bytes libres (encabezados incluidos)
size_t mm_heap_bytes(void);        // bytes totales obtenidos del sistema

#endif
